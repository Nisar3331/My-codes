"""
=======================================================
  Configuration — all values from environment variables
=======================================================
"""
import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AzureConfig:
    subscription_id:            str = field(default_factory=lambda: os.environ.get("AZURE_SUBSCRIPTION_ID", ""))
    tenant_id:                  str = field(default_factory=lambda: os.environ.get("AZURE_TENANT_ID", ""))
    resource_group:             str = field(default_factory=lambda: os.environ.get("AZURE_RESOURCE_GROUP", ""))
    adf_name:                   str = field(default_factory=lambda: os.environ.get("ADF_FACTORY_NAME", "pf-observability-datafactory"))
    adf_pipeline_name:          str = field(default_factory=lambda: os.environ.get("ADF_PIPELINE_NAME", ""))
    storage_connection_string:  str = field(default_factory=lambda: os.environ.get("AZURE_STORAGE_CONNECTION_STRING", ""))
    source_container:           str = field(default_factory=lambda: os.environ.get("SOURCE_CONTAINER", "pf-observability-blob-container"))
    landing_container:          str = field(default_factory=lambda: os.environ.get("LANDING_CONTAINER", "landing"))
    source_folder:              str = field(default_factory=lambda: os.environ.get("SOURCE_FOLDER", "raw"))
    landing_folder:             str = field(default_factory=lambda: os.environ.get("LANDING_FOLDER", "landing"))
    azure_openai_endpoint:      str = field(default_factory=lambda: os.environ.get("AZURE_OPENAI_ENDPOINT", ""))
    azure_openai_api_key:       str = field(default_factory=lambda: os.environ.get("AZURE_OPENAI_API_KEY", ""))
    azure_openai_api_version:   str = field(default_factory=lambda: os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"))
    llm_deployment_name:        str = field(default_factory=lambda: os.environ.get("LLM_DEPLOYMENT_NAME", "gpt-4o"))
    client_id:                  str = field(default_factory=lambda: os.environ.get("AZURE_CLIENT_ID", ""))
    client_secret:              str = field(default_factory=lambda: os.environ.get("AZURE_CLIENT_SECRET", ""))
    log_analytics_workspace_id: str = field(default_factory=lambda: os.environ.get("LOG_ANALYTICS_WORKSPACE_ID", ""))
    teams_webhook_url:          str = field(default_factory=lambda: os.environ.get("TEAMS_WEBHOOK_URL", ""))


@dataclass
class PipelineConfig:
    max_retry_attempts:      int = 3
    retry_delay_seconds:     int = 30
    pipeline_timeout_minutes:int = 60
    parquet_compression:     str = "snappy"


AZURE_CONFIG    = AzureConfig()
PIPELINE_CONFIG = PipelineConfig()

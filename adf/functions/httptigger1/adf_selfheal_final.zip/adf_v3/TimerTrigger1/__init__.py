"""
=======================================================
  TimerTrigger1 — Backup Log Analytics Poller
  Runs every 5 minutes automatically.
  Same 7-step flow as HttpTrigger1 but driven by timer.
  Used when Alert Rule does not fire (enterprise restriction).
=======================================================
"""
import logging
import os
import sys
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import azure.functions as func

from src.llm_error_detector import LlmErrorDetector
from src.error_resolver import AdfErrorResolver
from src.adf_pipeline_manager import AdfPipelineManager
from src.policy import evaluate_policy, PolicyOutcome
from src.incident_store import is_already_handled, mark_as_handled
from config.settings import AZURE_CONFIG

WORKSPACE_ID = os.environ.get("LOG_ANALYTICS_WORKSPACE_ID", "")


def main(mytimer: func.TimerRequest) -> None:
    logging.info("=== TimerTrigger1 fired at %s ===", datetime.now(timezone.utc))

    if mytimer.past_due:
        logging.warning("Timer is past due")

    if not WORKSPACE_ID:
        logging.error("LOG_ANALYTICS_WORKSPACE_ID not set — add to Environment variables")
        return

    # STEP 1 — Error Detection
    logging.info("STEP 1 — Querying Log Analytics for failures ...")
    failures = _query_failures()

    if not failures:
        logging.info("No pipeline failures in last 10 minutes")
        return

    logging.info("Found %d failure(s)", len(failures))

    for failure in failures:
        _run_healing_flow(failure)


def _query_failures() -> list:
    try:
        from azure.monitor.query import LogsQueryClient, LogsQueryStatus
        from azure.identity import ClientSecretCredential

        cred   = ClientSecretCredential(
            tenant_id=AZURE_CONFIG.tenant_id,
            client_id=AZURE_CONFIG.client_id,
            client_secret=AZURE_CONFIG.client_secret,
        )
        client = LogsQueryClient(cred)

        query = """
        ADFActivityRun
        | where Status == "Failed"
        | where TimeGenerated >= ago(10m)
        | project
            pipelineName  = PipelineName,
            runId         = PipelineRunId,
            activityName  = ActivityName,
            errorCode     = extract(@"ErrorCode=([^,]+)", 1, ErrorMessage),
            errorMessage  = extract(@"Message=(.*?)(,Source=|$)", 1, ErrorMessage),
            errorRaw      = ErrorMessage
        | order by TimeGenerated desc
        """

        response = client.query_workspace(
            workspace_id=WORKSPACE_ID,
            query=query,
            timespan=timedelta(minutes=10),
        )

        if response.status != LogsQueryStatus.SUCCESS:
            logging.error("Query failed: %s", response.partial_error)
            return []

        if not response.tables or not response.tables[0].rows:
            return []

        cols     = response.tables[0].columns
        failures = [dict(zip(cols, row)) for row in response.tables[0].rows]
        logging.info("Failures found: %d", len(failures))
        return failures

    except Exception as exc:
        logging.error("Log Analytics query error: %s", exc)
        return []


def _run_healing_flow(failure: dict) -> None:
    pipeline_name = failure.get("pipelineName", "unknown-pipeline")
    run_id        = failure.get("runId", "unknown")
    activity_name = failure.get("activityName")
    error_message = (
        failure.get("errorMessage") or
        failure.get("errorRaw") or
        f"Pipeline {pipeline_name} failed"
    )

    logging.error("ADF FAILURE | pipeline=%s | run_id=%s | error=%s",
                  pipeline_name, run_id, str(error_message)[:200])

    # STEP 2 — Classify + LLM generates fix
    logging.info("STEP 2 — LLM classification | pipeline=%s", pipeline_name)
    try:
        detector  = LlmErrorDetector()
        detection = detector.detect(
            error_message=str(error_message),
            pipeline_name=pipeline_name,
            activity_name=activity_name,
        )
        logging.info("[%s] Code=%s | Confidence=%.0f%%",
                     pipeline_name,
                     detection.get("matched_error_code"),
                     detection.get("confidence", 0) * 100)
    except Exception as exc:
        logging.error("[%s] Detection failed: %s", pipeline_name, exc)
        return

    # STEP 5 — Execute fix
    logging.info("STEP 5 — Execute fix | pipeline=%s", pipeline_name)
    try:
        resolver   = AdfErrorResolver()
        resolution = resolver.resolve(detection)
    except Exception as exc:
        logging.error("[%s] Resolver failed: %s", pipeline_name, exc)
        resolution = {"success": False, "validator_passed": False}

    # STEPS 3+4 — Safety check + notify
    already_handled = is_already_handled(pipeline_name, detection.get("matched_error_code", "UNKNOWN"))
    decision        = evaluate_policy(detection, resolution, pipeline_name, already_handled)

    logging.info("[%s] Policy → %s | blast=%s | reason=%s",
                 pipeline_name, decision.outcome, decision.blast_radius, decision.rationale)

    # STEP 6 — Rerun pipeline
    if decision.outcome == PolicyOutcome.EXECUTE:
        logging.info("STEP 6 — Rerunning pipeline | pipeline=%s", pipeline_name)
        try:
            mgr        = AdfPipelineManager()
            new_run_id = mgr.restart_pipeline(pipeline_name=pipeline_name, delay_seconds=30)
            mark_as_handled(pipeline_name, detection.get("matched_error_code", "UNKNOWN"), run_id)
            logging.info("[%s] RESTARTED SUCCESSFULLY | new_run_id=%s", pipeline_name, new_run_id)

            # STEP 7 — Check status
            logging.info("STEP 7 — Checking status | new_run_id=%s", new_run_id)
            import time
            time.sleep(60)
            status = mgr.check_status(new_run_id)
            logging.info("[%s] Final status: %s", pipeline_name, status.get("status"))

        except Exception as exc:
            logging.error("[%s] Restart failed: %s", pipeline_name, exc)

    elif decision.outcome == PolicyOutcome.BLOCKED:
        logging.error("[%s] BLOCKED | fix=%s", pipeline_name, decision.llm_fix)
        mark_as_handled(pipeline_name, detection.get("matched_error_code", "UNKNOWN"), run_id)

    elif decision.outcome == PolicyOutcome.NOTIFY:
        logging.warning("[%s] NOTIFY | reason=%s", pipeline_name, decision.rationale)
        mark_as_handled(pipeline_name, detection.get("matched_error_code", "UNKNOWN"), run_id)

    elif decision.outcome == PolicyOutcome.SKIPPED:
        logging.info("[%s] SKIPPED — duplicate", pipeline_name)

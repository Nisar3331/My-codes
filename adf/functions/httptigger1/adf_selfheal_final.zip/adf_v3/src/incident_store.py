"""
=======================================================
  Incident Store — prevents duplicate restarts
  Stores handled incidents in Azure Blob Storage
  Cooldown: 30 minutes per pipeline+error combination
=======================================================
"""
import json
import hashlib
from datetime import datetime, timezone
from src.logger import get_logger
from config.settings import AZURE_CONFIG

logger    = get_logger(__name__)
COOLDOWN  = 30   # minutes
CONTAINER = "adf-incidents"


def _key(pipeline_name: str, error_code: str) -> str:
    raw = f"{pipeline_name}:{error_code}:{datetime.now(timezone.utc).strftime('%Y-%m-%d-%H')}"
    return hashlib.md5(raw.encode()).hexdigest()


def is_already_handled(pipeline_name: str, error_code: str) -> bool:
    try:
        from azure.storage.blob import BlobServiceClient
        conn = AZURE_CONFIG.storage_connection_string
        if not conn:
            return False
        client = BlobServiceClient.from_connection_string(conn)
        try:
            client.get_container_client(CONTAINER).create_container()
        except Exception:
            pass
        blob_name = f"incident_{_key(pipeline_name, error_code)}.json"
        try:
            data       = json.loads(client.get_blob_client(CONTAINER, blob_name).download_blob().readall())
            handled_at = datetime.fromisoformat(data["handled_at"])
            age        = (datetime.now(timezone.utc) - handled_at).total_seconds() / 60
            if age < COOLDOWN:
                logger.warning("DUPLICATE | [%s] [%s] handled %.0f min ago — skipping",
                               pipeline_name, error_code, age)
                return True
        except Exception:
            pass
        return False
    except Exception as exc:
        logger.warning("Incident store check failed: %s — allowing", exc)
        return False


def mark_as_handled(pipeline_name: str, error_code: str, run_id: str = "") -> None:
    try:
        from azure.storage.blob import BlobServiceClient
        conn = AZURE_CONFIG.storage_connection_string
        if not conn:
            return
        client = BlobServiceClient.from_connection_string(conn)
        try:
            client.get_container_client(CONTAINER).create_container()
        except Exception:
            pass
        blob_name = f"incident_{_key(pipeline_name, error_code)}.json"
        data = {
            "pipeline_name": pipeline_name,
            "error_code":    error_code,
            "run_id":        run_id,
            "handled_at":    datetime.now(timezone.utc).isoformat(),
        }
        client.get_blob_client(CONTAINER, blob_name).upload_blob(json.dumps(data), overwrite=True)
        logger.info("Incident recorded: [%s] [%s]", pipeline_name, error_code)
    except Exception as exc:
        logger.warning("Could not record incident: %s", exc)

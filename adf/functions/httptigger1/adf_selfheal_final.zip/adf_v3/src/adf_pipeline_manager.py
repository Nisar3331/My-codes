"""
=======================================================
  ADF Pipeline Manager
  Step 6 — Rerun pipeline
  Step 7 — Check status
=======================================================
"""
import time
from typing import Dict, Any, Optional
from datetime import datetime, timezone

from azure.identity import ClientSecretCredential
from azure.mgmt.datafactory import DataFactoryManagementClient

from src.logger import get_logger
from config.settings import AZURE_CONFIG, PIPELINE_CONFIG

logger = get_logger(__name__)

_TERMINAL = {"Succeeded", "Failed", "Cancelled", "Canceling"}


class AdfPipelineManager:

    def __init__(self):
        cred = ClientSecretCredential(
            tenant_id=AZURE_CONFIG.tenant_id,
            client_id=AZURE_CONFIG.client_id,
            client_secret=AZURE_CONFIG.client_secret,
        )
        self._client  = DataFactoryManagementClient(cred, AZURE_CONFIG.subscription_id)
        self._rg      = AZURE_CONFIG.resource_group
        self._factory = AZURE_CONFIG.adf_name
        self._default = AZURE_CONFIG.adf_pipeline_name
        self._timeout = PIPELINE_CONFIG.pipeline_timeout_minutes * 60

    def restart_pipeline(
        self,
        pipeline_name:  Optional[str] = None,
        parameters:     Optional[Dict[str, Any]] = None,
        delay_seconds:  int = 0,
    ) -> str:
        """Step 6 — Rerun pipeline."""
        name = pipeline_name or self._default
        if not name:
            raise ValueError("pipeline_name is required")
        if delay_seconds > 0:
            logger.info("Waiting %ds before restarting %s ...", delay_seconds, name)
            time.sleep(delay_seconds)
        logger.info("Triggering pipeline: %s | factory: %s", name, self._factory)
        response = self._client.pipelines.create_run(
            resource_group_name=self._rg,
            factory_name=self._factory,
            pipeline_name=name,
            parameters=parameters or {},
        )
        logger.info("New run_id: %s", response.run_id)
        return response.run_id

    def check_status(self, run_id: str) -> Dict[str, Any]:
        """Step 7 — Check status of restarted pipeline."""
        logger.info("Checking status for run_id: %s", run_id)
        start   = datetime.now(timezone.utc)
        elapsed = 0

        while elapsed < self._timeout:
            run     = self._client.pipeline_runs.get(self._rg, self._factory, run_id)
            status  = run.status
            elapsed = (datetime.now(timezone.utc) - start).total_seconds()
            logger.info("Status: %-12s | Elapsed: %ds", status, int(elapsed))

            if status in _TERMINAL:
                result = {
                    "run_id":           run_id,
                    "status":           status,
                    "duration_seconds": int(elapsed),
                    "message":          run.message or "",
                    "success":          status == "Succeeded",
                }
                if status == "Succeeded":
                    logger.info("Pipeline SUCCEEDED | run_id=%s", run_id)
                else:
                    logger.error("Pipeline %s | run_id=%s | message=%s",
                                 status, run_id, run.message or "")
                return result

            time.sleep(30)

        return {
            "run_id":  run_id,
            "status":  "MonitorTimeout",
            "success": False,
            "message": "Status check timed out",
        }

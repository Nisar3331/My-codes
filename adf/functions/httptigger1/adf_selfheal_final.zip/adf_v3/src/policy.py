"""
=======================================================
  Policy Engine
  Steps 3 + 4 + 5 of the self-healing flow:
    Step 3 — Safety / Blast Radius check
    Step 4 — Notify if HIGH risk
    Step 5 — Execute fix decision

  Flow:
    Error Detection
      → Classify (KNOWN/UNKNOWN)       [llm_error_detector.py]
      → LLM generates fix              [llm_error_detector.py]
      → Safety / Blast Radius check    [THIS FILE]
      → Notify if HIGH risk            [THIS FILE]
      → Execute fix                    [THIS FILE → adf_pipeline_manager.py]
      → Rerun pipeline                 [adf_pipeline_manager.py]
      → Check status                   [adf_pipeline_manager.py]
=======================================================
"""
import json
import logging
import os
from dataclasses import dataclass
from typing import Dict, Any, Optional
from enum import Enum

from src.logger import get_logger

logger = get_logger(__name__)


# =============================================================================
#  Enums
# =============================================================================

class ErrorClass(str, Enum):
    KNOWN   = "KNOWN"
    UNKNOWN = "UNKNOWN"


class BlastRadius(str, Enum):
    LOW    = "LOW"     # restarts one pipeline only — safe
    MEDIUM = "MEDIUM"  # touches ADF config or storage — moderate
    HIGH   = "HIGH"    # schema change, data contract, unknown — risky


class ExecutionMode(str, Enum):
    AUTO        = "AUTO"         # execute immediately
    CONDITIONAL = "CONDITIONAL"  # execute only if validator passes
    MANUAL      = "MANUAL"       # block — human must fix first


class PolicyOutcome(str, Enum):
    EXECUTE  = "EXECUTE"   # run fix and restart pipeline
    BLOCKED  = "BLOCKED"   # do not restart — human must fix
    NOTIFY   = "NOTIFY"    # alert team and wait for approval
    SKIPPED  = "SKIPPED"   # duplicate — already handled recently


# =============================================================================
#  Policy Rules per error code
# =============================================================================

POLICY_RULES: Dict[str, Dict[str, Any]] = {

    "ADF-001": {
        "description":    "Linked Service Connection Failure",
        "blast_radius":   BlastRadius.LOW,
        "execution_mode": ExecutionMode.CONDITIONAL,
        "notify_team":    False,
        "safe_to_retry":  True,
        "rationale":      "Transient connection — safe to retry after credential validation",
    },
    "ADF-002": {
        "description":    "Schema Mismatch",
        "blast_radius":   BlastRadius.MEDIUM,
        "execution_mode": ExecutionMode.CONDITIONAL,
        "notify_team":    True,
        "safe_to_retry":  False,
        "rationale":      "Schema change affects downstream — validate schema before restart",
    },
    "ADF-003": {
        "description":    "File Not Found",
        "blast_radius":   BlastRadius.LOW,
        "execution_mode": ExecutionMode.AUTO,
        "notify_team":    False,
        "safe_to_retry":  True,
        "rationale":      "File may have arrived late — poll blob and restart automatically",
    },
    "ADF-004": {
        "description":    "Pipeline Timeout",
        "blast_radius":   BlastRadius.LOW,
        "execution_mode": ExecutionMode.AUTO,
        "notify_team":    False,
        "safe_to_retry":  True,
        "rationale":      "Transient timeout — safe to restart with higher DIU",
    },
    "ADF-005": {
        "description":    "Stored Procedure Failure",
        "blast_radius":   BlastRadius.LOW,
        "execution_mode": ExecutionMode.AUTO,
        "notify_team":    False,
        "safe_to_retry":  True,
        "rationale":      "Deadlock or transient SP failure — safe to retry",
    },
    "ADF-006": {
        "description":    "Parquet Invalid Column Name",
        "blast_radius":   BlastRadius.HIGH,
        "execution_mode": ExecutionMode.MANUAL,
        "notify_team":    True,
        "safe_to_retry":  False,
        "rationale":      "Data contract issue — restarting without fixing ADF column mapping will loop forever. Human must fix mapping first.",
    },
    "UNKNOWN": {
        "description":    "Unclassified Error",
        "blast_radius":   BlastRadius.HIGH,
        "execution_mode": ExecutionMode.MANUAL,
        "notify_team":    True,
        "safe_to_retry":  False,
        "rationale":      "Unknown error — never auto-restart. Notify team for investigation.",
    },
}


# =============================================================================
#  Policy Decision
# =============================================================================

@dataclass
class PolicyDecision:
    error_code:       str
    error_class:      ErrorClass
    blast_radius:     BlastRadius
    execution_mode:   ExecutionMode
    outcome:          PolicyOutcome
    notify_team:      bool
    safe_to_retry:    bool
    rationale:        str
    llm_fix:          Optional[str] = None
    validator_passed: bool = False


# =============================================================================
#  Policy Engine
# =============================================================================

class PolicyEngine:
    """
    Full policy flow:
      Step 3 — Safety / Blast Radius check
      Step 4 — Notify if HIGH risk
      Step 5 — Decide: EXECUTE / BLOCKED / NOTIFY / SKIPPED
    """

    def evaluate(
        self,
        detection:       Dict[str, Any],
        resolution:      Dict[str, Any],
        pipeline_name:   str,
        already_handled: bool = False,
    ) -> PolicyDecision:

        error_code  = detection.get("matched_error_code", "UNKNOWN")
        confidence  = detection.get("confidence", 0.0)
        error_class = self._classify(error_code, confidence)
        rule        = POLICY_RULES.get(error_code, POLICY_RULES["UNKNOWN"])

        logger.info("PolicyEngine | pipeline=%s | error=%s | class=%s | confidence=%.0f%%",
                    pipeline_name, error_code, error_class, confidence * 100)

        # ── Step 3: Blast Radius check ────────────────────────────────────
        blast_radius = BlastRadius(rule["blast_radius"])
        logger.info("Blast radius: %s", blast_radius)

        # ── LLM fix plan ──────────────────────────────────────────────────
        llm_fix = self._extract_llm_fix(detection)

        # ── Step 5: Decide outcome ────────────────────────────────────────
        outcome = self._decide(rule, error_class, blast_radius, resolution, already_handled)
        logger.info("Policy outcome: %s | reason: %s", outcome, rule["rationale"])

        # ── Step 4: Notify if HIGH risk ───────────────────────────────────
        notify_team = rule["notify_team"] or blast_radius == BlastRadius.HIGH
        if notify_team and outcome in [PolicyOutcome.BLOCKED, PolicyOutcome.NOTIFY]:
            self._send_notification(pipeline_name, error_code, outcome, rule["rationale"], llm_fix)

        return PolicyDecision(
            error_code=error_code,
            error_class=error_class,
            blast_radius=blast_radius,
            execution_mode=ExecutionMode(rule["execution_mode"]),
            outcome=outcome,
            notify_team=notify_team,
            safe_to_retry=rule["safe_to_retry"],
            rationale=rule["rationale"],
            llm_fix=llm_fix,
        )

    def _classify(self, error_code: str, confidence: float) -> ErrorClass:
        if error_code == "UNKNOWN" or confidence < 0.5:
            return ErrorClass.UNKNOWN
        return ErrorClass.KNOWN

    def _extract_llm_fix(self, detection: Dict[str, Any]) -> Optional[str]:
        steps = detection.get("llm_fix_plan", [])
        if steps:
            return " | ".join(steps[:3])
        steps = detection.get("suggested_steps", [])
        if steps:
            return " | ".join(steps[:3])
        catalog = detection.get("catalog_entry", {})
        steps   = catalog.get("troubleshooting_steps", [])
        if steps:
            return " | ".join(steps[:3])
        return detection.get("detected_root_cause")

    def _decide(
        self,
        rule:            Dict[str, Any],
        error_class:     ErrorClass,
        blast_radius:    BlastRadius,
        resolution:      Dict[str, Any],
        already_handled: bool,
    ) -> PolicyOutcome:

        if already_handled:
            return PolicyOutcome.SKIPPED

        mode = ExecutionMode(rule["execution_mode"])

        if mode == ExecutionMode.MANUAL:
            return PolicyOutcome.BLOCKED

        if error_class == ErrorClass.UNKNOWN:
            return PolicyOutcome.BLOCKED

        if blast_radius == BlastRadius.HIGH:
            return PolicyOutcome.NOTIFY if not resolution.get("validator_passed") else PolicyOutcome.EXECUTE

        if mode == ExecutionMode.CONDITIONAL:
            return PolicyOutcome.EXECUTE if resolution.get("success") else PolicyOutcome.NOTIFY

        if mode == ExecutionMode.AUTO:
            return PolicyOutcome.EXECUTE

        return PolicyOutcome.BLOCKED

    def _send_notification(
        self,
        pipeline_name: str,
        error_code:    str,
        outcome:       PolicyOutcome,
        rationale:     str,
        llm_fix:       Optional[str],
    ) -> None:
        message = (
            f"🚨 ADF SELF-HEALING ALERT\n"
            f"Pipeline   : {pipeline_name}\n"
            f"Error Code : {error_code}\n"
            f"Outcome    : {outcome}\n"
            f"Rationale  : {rationale}\n"
            f"LLM Fix    : {llm_fix or 'No suggestion'}\n"
            f"Action Needed: {'Manual fix required in ADF Studio' if outcome == PolicyOutcome.BLOCKED else 'Team review required'}"
        )
        logger.error("NOTIFICATION:\n%s", message)

        teams_url = os.environ.get("TEAMS_WEBHOOK_URL", "")
        if teams_url:
            try:
                import urllib.request
                data = json.dumps({"text": message}).encode("utf-8")
                req  = urllib.request.Request(
                    teams_url,
                    data=data,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=10)
                logger.info("Teams notification sent")
            except Exception as exc:
                logger.warning("Teams notification failed: %s", exc)


def evaluate_policy(
    detection:       Dict[str, Any],
    resolution:      Dict[str, Any],
    pipeline_name:   str,
    already_handled: bool = False,
) -> PolicyDecision:
    """Entry point for HttpTrigger1 and TimerTrigger1."""
    return PolicyEngine().evaluate(
        detection=detection,
        resolution=resolution,
        pipeline_name=pipeline_name,
        already_handled=already_handled,
    )

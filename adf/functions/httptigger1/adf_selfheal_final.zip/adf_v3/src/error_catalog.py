"""
=======================================================
  ADF Error Catalog — 6 known error types
  ADF-001 to ADF-006
=======================================================
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class AdfError:
    error_code:            str
    error_name:            str
    common_error_message:  str
    main_cause:            str
    business_impact:       str
    troubleshooting_steps: List[str]
    keywords:              List[str]
    auto_resolvable:       bool = True
    resolution_action:     str  = ""
    severity:              str  = "HIGH"


ADF_ERROR_CATALOG: List[AdfError] = [

    AdfError(
        error_code="ADF-001",
        error_name="Linked Service Connection Failure",
        common_error_message="Cannot connect to SQL Database or Storage account",
        main_cause="Wrong credentials, expired secret, firewall issue or private endpoint issue",
        business_impact="Pipeline fails at connection stage",
        troubleshooting_steps=[
            "Test linked service connection in ADF Studio",
            "Check credentials or Key Vault secret expiry",
            "Check firewall rules allow ADF IR IP",
            "Validate private endpoint connectivity",
        ],
        keywords=["connect", "connection", "credentials", "sql database", "storage account",
                  "linked service", "secret", "firewall", "sqlfailedtoconnect", "cannot connect",
                  "login failed", "timeout expired"],
        auto_resolvable=True,
        resolution_action="refresh_linked_service_credentials",
        severity="HIGH",
    ),

    AdfError(
        error_code="ADF-002",
        error_name="Copy Activity Schema Mismatch",
        common_error_message="Column mapping failed or column does not exist in source or sink",
        main_cause="Source and target columns differ — datatype mismatch or missing column",
        business_impact="Data copy fails or incorrect data loaded into target",
        troubleshooting_steps=[
            "Compare source and sink schema",
            "Refresh schema in ADF dataset",
            "Update column mapping in Copy Activity",
            "Check for newly added or renamed columns",
        ],
        keywords=["column", "schema", "mapping", "datatype", "mismatch",
                  "does not exist", "sink", "copy activity", "column mapping failed"],
        auto_resolvable=True,
        resolution_action="refresh_schema_and_remap_columns",
        severity="HIGH",
    ),

    AdfError(
        error_code="ADF-003",
        error_name="File Not Found in Source Path",
        common_error_message="The specified file does not exist",
        main_cause="File missing in Blob/ADLS path or not yet delivered by upstream",
        business_impact="Pipeline fails before ingestion starts",
        troubleshooting_steps=[
            "Check source folder path in blob storage",
            "Confirm file delivery from upstream system",
            "Check ADF trigger timing vs file arrival",
            "Add Get Metadata guard before Copy Activity",
        ],
        keywords=["file not found", "does not exist", "blob", "adls", "missing file",
                  "usererrorsourceblobnotexist", "required blob is missing", "404",
                  "containername", "blob storage", "usererror"],
        auto_resolvable=True,
        resolution_action="validate_source_path_and_wait_for_file",
        severity="MEDIUM",
    ),

    AdfError(
        error_code="ADF-004",
        error_name="Pipeline Timeout",
        common_error_message="Activity timed out",
        main_cause="Large data volume, slow query, or integration runtime performance issue",
        business_impact="Pipeline misses SLA, downstream reports delayed",
        troubleshooting_steps=[
            "Increase Copy Activity timeout setting",
            "Increase Data Integration Units (DIU) to 16 or 32",
            "Enable query partitioning on large tables",
            "Check IR CPU and memory in Azure Monitor",
        ],
        keywords=["timeout", "timed out", "sla", "slow", "integration runtime",
                  "data integration units", "performance", "large data"],
        auto_resolvable=True,
        resolution_action="increase_timeout_and_optimize_diu",
        severity="HIGH",
    ),

    AdfError(
        error_code="ADF-005",
        error_name="Stored Procedure Failure",
        common_error_message="SQL execution failed or stored procedure failed",
        main_cause="Deadlock, constraint violation, duplicate records, or invalid parameter",
        business_impact="Transformation or post-load processing stops midway",
        troubleshooting_steps=[
            "Run stored procedure manually in SSMS",
            "Validate input parameters from ADF",
            "Check for deadlocks in sys.dm_exec_requests",
            "Add MERGE or NOT EXISTS for duplicate prevention",
        ],
        keywords=["stored procedure", "sql", "deadlock", "constraint", "duplicate",
                  "violation", "parameter", "procedure failed", "sql execution"],
        auto_resolvable=True,
        resolution_action="retry_sp_with_dedup_and_deadlock_handling",
        severity="HIGH",
    ),

    AdfError(
        error_code="ADF-006",
        error_name="Parquet Invalid Column Name",
        common_error_message="Column name is invalid — cannot contain [,;{}()\\n\\t=]",
        main_cause="Source CSV or SQL view has column names with Parquet-invalid special characters",
        business_impact="Copy Activity fails — no data written to Parquet landing folder",
        troubleshooting_steps=[
            "Identify column with invalid chars in ADF Copy Activity → Mapping",
            "Rename column in ADF Mapping tab (e.g. order;id → order_id)",
            "Fix column name at source — SQL view alias or CSV header",
            "Use sanitise_column_names() in data_processor.py for CSV sources",
        ],
        keywords=["parquet", "invalid column name", "cannot contain", "parquetinvalidcolumnname",
                  "semicolon", "special character", "hybriddeliveryexception"],
        auto_resolvable=False,  # Must fix ADF mapping first — do NOT restart blindly
        resolution_action="sanitise_parquet_column_names",
        severity="HIGH",
    ),
]


def get_error_catalog_as_dict() -> List[Dict[str, Any]]:
    return [
        {
            "error_code":            e.error_code,
            "error_name":            e.error_name,
            "common_error_message":  e.common_error_message,
            "main_cause":            e.main_cause,
            "business_impact":       e.business_impact,
            "troubleshooting_steps": e.troubleshooting_steps,
            "keywords":              e.keywords,
            "auto_resolvable":       e.auto_resolvable,
            "resolution_action":     e.resolution_action,
            "severity":              e.severity,
        }
        for e in ADF_ERROR_CATALOG
    ]


def get_error_by_code(code: str) -> AdfError | None:
    return next((e for e in ADF_ERROR_CATALOG if e.error_code == code), None)

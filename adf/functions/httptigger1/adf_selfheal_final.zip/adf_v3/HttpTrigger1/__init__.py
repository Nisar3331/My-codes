"""
=======================================================
  HttpTrigger1 — ADF Self-Healing Handler
  Munich RE x Capgemini DataRend Program

  Triggered by: Azure Monitor Alert Rule
    → Action Group → this HTTP endpoint

  Full flow:
    Step 1 — Error Detection (parse Log Analytics payload)
    Step 2 — Classify + LLM generates fix
    Step 3 — Safety / Blast Radius check  [policy.py]
    Step 4 — Notify if HIGH risk          [policy.py]
    Step 5 — Execute fix                  [error_resolver.py]
    Step 6 — Rerun pipeline               [adf_pipeline_manager.py]
    Step 7 — Check status                 [adf_pipeline_manager.py]
=======================================================
"""

import json
import logging
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import azure.functions as func

from src.llm_error_detector import LlmErrorDetector
from src.error_resolver import AdfErrorResolver
from src.adf_pipeline_manager import AdfPipelineManager
from src.policy import evaluate_policy, PolicyOutcome
from src.incident_store import is_already_handled, mark_as_handled
from config.settings import AZURE_CONFIG


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Entry point — parameter MUST be 'req' to match function.json."""
    logging.info("=== HttpTrigger1 — Monitor Alert received ===")

    # ── Parse request body ────────────────────────────────────────────────
    try:
        body = req.get_json()
    except Exception as exc:
        logging.error("Failed to parse request body: %s", exc)
        return func.HttpResponse(
            json.dumps({"error": "Invalid JSON body"}),
            status_code=400,
            mimetype="application/json",
        )

    logging.info("Payload: %s", json.dumps(body, default=str)[:800])

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 1 — ERROR DETECTION
    # Extract pipeline name + error from Log Analytics searchResults
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEP 1 — Error Detection")
    pipeline_info = _extract_from_payload(body)

    if not pipeline_info:
        logging.warning("No pipeline info — ignoring alert")
        return func.HttpResponse(
            json.dumps({"status": "ignored"}),
            status_code=200,
            mimetype="application/json",
        )

    pipeline_name = pipeline_info["pipeline_name"]
    run_id        = pipeline_info.get("run_id", "unknown")
    activity_name = pipeline_info.get("activity_name")
    error_message = pipeline_info.get("error_message", "")

    logging.error(
        "ADF FAILURE DETECTED | pipeline=%s | run_id=%s | activity=%s | error=%s",
        pipeline_name, run_id, activity_name, str(error_message)[:300],
    )

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 2 — CLASSIFY + LLM GENERATES FIX
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEP 2 — Classify + LLM fix generation | pipeline=%s", pipeline_name)
    try:
        detector  = LlmErrorDetector()
        detection = detector.detect(
            error_message=str(error_message),
            pipeline_name=pipeline_name,
            activity_name=activity_name,
        )
        logging.info(
            "[%s] Class=%s | Code=%s | Confidence=%.0f%% | LLM fix=%s",
            pipeline_name,
            detection.get("error_class"),
            detection.get("matched_error_code"),
            detection.get("confidence", 0) * 100,
            str(detection.get("llm_fix_plan", []))[:150],
        )
    except Exception as exc:
        logging.error("[%s] LLM detection failed: %s", pipeline_name, exc)
        detection = {
            "matched_error_code": "UNKNOWN",
            "error_class":        "UNKNOWN",
            "confidence":         0.0,
            "auto_resolvable":    False,
            "resolution_action":  "manual_investigation_required",
            "llm_fix_plan":       ["Check ADF Monitor", "Review Log Analytics", "Escalate to L2"],
            "suggested_steps":    [],
        }

    detected_code = detection.get("matched_error_code", "UNKNOWN")

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 5 — EXECUTE FIX (resolver)
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEP 5 — Execute fix | pipeline=%s | action=%s",
                 pipeline_name, detection.get("resolution_action"))
    try:
        resolver   = AdfErrorResolver()
        resolution = resolver.resolve(detection)
        logging.info(
            "[%s] Resolver: success=%s | validator_passed=%s | %s",
            pipeline_name,
            resolution.get("success"),
            resolution.get("validator_passed"),
            resolution.get("message", "")[:150],
        )
    except Exception as exc:
        logging.error("[%s] Resolver failed: %s", pipeline_name, exc)
        resolution = {"success": False, "validator_passed": False}

    # ═══════════════════════════════════════════════════════════════════════
    # STEPS 3 + 4 — SAFETY CHECK + NOTIFY
    # Policy engine: blast radius check + notification
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEPS 3+4 — Safety check + notify | pipeline=%s", pipeline_name)
    already_handled = is_already_handled(pipeline_name, detected_code)

    decision = evaluate_policy(
        detection=detection,
        resolution=resolution,
        pipeline_name=pipeline_name,
        already_handled=already_handled,
    )

    logging.info(
        "[%s] Policy → outcome=%s | blast=%s | notify=%s | reason=%s",
        pipeline_name,
        decision.outcome,
        decision.blast_radius,
        decision.notify_team,
        decision.rationale,
    )

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 6 — RERUN PIPELINE
    # ═══════════════════════════════════════════════════════════════════════
    restart_result = {"restarted": False, "reason": decision.rationale}
    status_result  = {}

    if decision.outcome == PolicyOutcome.EXECUTE:
        logging.info("STEP 6 — Rerun pipeline | pipeline=%s", pipeline_name)
        try:
            mgr        = AdfPipelineManager()
            new_run_id = mgr.restart_pipeline(
                pipeline_name=pipeline_name,
                delay_seconds=30,
            )
            restart_result = {"restarted": True, "new_run_id": new_run_id}
            logging.info("[%s] RESTARTED SUCCESSFULLY | new_run_id=%s",
                         pipeline_name, new_run_id)
            mark_as_handled(pipeline_name, detected_code, run_id)

            # ═══════════════════════════════════════════════════════════════
            # STEP 7 — CHECK STATUS
            # Poll pipeline status for up to 2 minutes
            # ═══════════════════════════════════════════════════════════════
            logging.info("STEP 7 — Check status | new_run_id=%s", new_run_id)
            try:
                import time
                time.sleep(60)  # wait 60s before first status check
                status_result = mgr.check_status(new_run_id)
                logging.info(
                    "[%s] Status check: %s | duration=%ss",
                    pipeline_name,
                    status_result.get("status"),
                    status_result.get("duration_seconds"),
                )
            except Exception as exc:
                logging.warning("[%s] Status check failed: %s", pipeline_name, exc)
                status_result = {"status": "CheckFailed", "error": str(exc)}

        except Exception as exc:
            restart_result = {"restarted": False, "error": str(exc)}
            logging.error("[%s] Restart failed: %s", pipeline_name, exc)

    elif decision.outcome == PolicyOutcome.BLOCKED:
        logging.error(
            "[%s] BLOCKED — manual fix required | code=%s | reason=%s | fix=%s",
            pipeline_name, detected_code, decision.rationale, decision.llm_fix,
        )
        mark_as_handled(pipeline_name, detected_code, run_id)

    elif decision.outcome == PolicyOutcome.NOTIFY:
        logging.warning(
            "[%s] NOTIFY — team alerted | code=%s | reason=%s",
            pipeline_name, detected_code, decision.rationale,
        )
        mark_as_handled(pipeline_name, detected_code, run_id)

    elif decision.outcome == PolicyOutcome.SKIPPED:
        logging.info("[%s] SKIPPED — duplicate incident already handled recently",
                     pipeline_name)

    # ── Final result ──────────────────────────────────────────────────────
    result = {
        "step1_detection": {
            "pipeline_name": pipeline_name,
            "run_id":        run_id,
            "activity_name": activity_name,
            "error_message": str(error_message)[:200],
        },
        "step2_classification": {
            "error_code":  detected_code,
            "error_class": detection.get("error_class"),
            "confidence":  detection.get("confidence", 0),
            "llm_fix":     decision.llm_fix,
        },
        "step3_blast_radius": str(decision.blast_radius),
        "step4_notified":     decision.notify_team,
        "step5_resolution": {
            "success":          resolution.get("success"),
            "validator_passed": resolution.get("validator_passed"),
            "message":          resolution.get("message", ""),
        },
        "step6_restart":    restart_result,
        "step7_status":     status_result,
        "policy_outcome":   str(decision.outcome),
        "rationale":        decision.rationale,
    }

    logging.info("[%s] All steps complete: %s",
                 pipeline_name, json.dumps(result, default=str))

    return func.HttpResponse(
        json.dumps(result, default=str),
        status_code=200,
        mimetype="application/json",
    )


def _extract_from_payload(data: dict) -> dict | None:
    """
    Extract pipeline info from Azure Monitor Log Alert payload.
    Priority 1: searchResults.tables (Log Analytics query results)
    Priority 2: alertContext.properties (fallback)
    """
    payload   = data.get("data", data)
    alert_ctx = payload.get("alertContext", {})

    # Priority 1 — Log Analytics searchResults
    search = alert_ctx.get("searchResults", {})
    tables = search.get("tables", [])
    logging.info("searchResults tables: %d", len(tables))

    if tables and tables[0].get("rows"):
        columns = [c["name"] for c in tables[0]["columns"]]
        values  = tables[0]["rows"][0]
        row     = dict(zip(columns, values))
        logging.info("Row from searchResults: %s", json.dumps(row, default=str))

        pipeline_name = (
            row.get("pipelineName") or
            row.get("PipelineName") or ""
        )
        error_message = (
            row.get("errorMessage") or
            row.get("ErrorMessage") or
            row.get("errorMessageRaw") or ""
        )

        if pipeline_name:
            return {
                "pipeline_name": pipeline_name,
                "run_id":        row.get("runId") or row.get("RunId"),
                "activity_name": row.get("activityName") or row.get("ActivityName"),
                "error_code":    row.get("errorCode") or row.get("ErrorCode"),
                "error_message": error_message,
                "source":        "log_analytics",
            }

    logging.warning("searchResults empty — using properties fallback")

    # Priority 2 — properties fallback
    essentials = payload.get("essentials", {})
    properties = alert_ctx.get("properties", {})

    if essentials.get("monitorCondition") == "Resolved":
        return None

    return {
        "pipeline_name": (
            properties.get("pipelineName") or
            AZURE_CONFIG.adf_pipeline_name or
            "unknown-pipeline"
        ),
        "run_id":        properties.get("runId"),
        "activity_name": properties.get("activityName"),
        "error_code":    properties.get("errorCode"),
        "error_message": (
            properties.get("errorMessage") or
            f"ADF pipeline failure — alert: {essentials.get('alertRule')}"
        ),
        "source": "properties_fallback",
    }

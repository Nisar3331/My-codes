"""
=======================================================
  LLM Error Detector
  FIXED: ADF-006 priority rule in fallback detection
         Parquet errors now correctly detected as ADF-006
         not ADF-002
=======================================================
"""
import json
from typing import Optional, Dict, Any

from openai import AzureOpenAI

from src.logger import get_logger
from src.error_catalog import ADF_ERROR_CATALOG, get_error_catalog_as_dict, get_error_by_code
from config.settings import AZURE_CONFIG

logger = get_logger(__name__)

_SYSTEM_PROMPT = """
You are an expert Azure Data Factory (ADF) diagnostics assistant for Munich RE.

Given an ADF pipeline error, you must:
1. Classify it as KNOWN (matches catalog) or UNKNOWN
2. Match it to the closest error code in the catalog
3. Generate a clear fix plan

Return ONLY valid JSON — no extra text:
{
  "matched_error_code": "<ADF-XXX or UNKNOWN>",
  "matched_error_name": "<string>",
  "error_class": "<KNOWN or UNKNOWN>",
  "confidence": <0.0 to 1.0>,
  "detected_root_cause": "<concise root cause>",
  "resolution_action": "<resolution_action from catalog>",
  "llm_fix_plan": ["<fix step 1>", "<fix step 2>", "<fix step 3>"],
  "auto_resolvable": <true|false>,
  "severity": "<HIGH|MEDIUM|LOW>",
  "explanation": "<1-2 sentence explanation>"
}

Rules:
- confidence > 0.5 = KNOWN, otherwise UNKNOWN
- Never invent error codes not in the catalog
- llm_fix_plan must have 3 actionable steps
- ParquetInvalidColumnName ALWAYS maps to ADF-006 never ADF-002
"""


class LlmErrorDetector:

    def __init__(self):
        endpoint = AZURE_CONFIG.azure_openai_endpoint.rstrip("/")
        if "/openai" in endpoint:
            endpoint = endpoint.split("/openai")[0]
        endpoint = endpoint + "/"

        self._client     = AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=AZURE_CONFIG.azure_openai_api_key,
            api_version=AZURE_CONFIG.azure_openai_api_version,
        )
        self._deployment = AZURE_CONFIG.llm_deployment_name
        self._catalog    = get_error_catalog_as_dict()

    def detect(
        self,
        error_message:      str,
        pipeline_name:      Optional[str] = None,
        activity_name:      Optional[str] = None,
        additional_context: Optional[str] = None,
    ) -> Dict[str, Any]:
        logger.info("LLM detection started | pipeline=%s | error=%s",
                    pipeline_name, error_message[:150])

        prompt = self._build_prompt(error_message, pipeline_name, activity_name, additional_context)

        try:
            response = self._client.chat.completions.create(
                model=self._deployment,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user",   "content": prompt},
                ],
                temperature=0.1,
                max_tokens=1000,
                response_format={"type": "json_object"},
            )
            result = json.loads(response.choices[0].message.content)
            self._enrich(result)
            logger.info("Detection complete — Code: %s | Confidence: %.2f | Auto: %s",
                        result.get("matched_error_code"),
                        result.get("confidence", 0),
                        result.get("auto_resolvable"))
            return result

        except Exception as exc:
            logger.error("LLM call failed: %s — using keyword fallback", exc)
            return self._fallback_detection(error_message)

    def _build_prompt(self, error_message, pipeline_name, activity_name, additional_context):
        parts = ["## ADF Pipeline Error\n"]
        if pipeline_name:
            parts.append(f"Pipeline : {pipeline_name}")
        if activity_name:
            parts.append(f"Activity : {activity_name}")
        parts.append(f"\nError Message:\n```\n{error_message}\n```")
        if additional_context:
            parts.append(f"\nContext: {additional_context}")
        parts.append("\n## Error Catalog\n```json")
        parts.append(json.dumps(self._catalog, indent=2))
        parts.append("```\nClassify and return JSON fix plan.")
        return "\n".join(parts)

    def _enrich(self, result: Dict[str, Any]) -> None:
        code = result.get("matched_error_code", "UNKNOWN")
        if code != "UNKNOWN":
            entry = get_error_by_code(code)
            if entry:
                result["catalog_entry"] = {
                    "error_code":            entry.error_code,
                    "error_name":            entry.error_name,
                    "main_cause":            entry.main_cause,
                    "business_impact":       entry.business_impact,
                    "resolution_action":     entry.resolution_action,
                    "troubleshooting_steps": entry.troubleshooting_steps,
                }

    def _fallback_detection(self, error_message: str) -> Dict[str, Any]:
        logger.warning("Using keyword fallback detection")
        error_lower = (error_message or "").lower()

        # ── HIGH PRIORITY RULE — ADF-006 ──────────────────────────────────
        # Must come BEFORE generic keyword scan.
        # Parquet column errors were being misclassified as ADF-002
        # because "column" was a generic keyword match.
        # ──────────────────────────────────────────────────────────────────
        if (
            "parquetinvalidcolumnname"        in error_lower or
            "parquet invalid column name"     in error_lower or
            "column name is invalid"          in error_lower or
            "column name cannot contain"      in error_lower or
            "cannot contain these character"  in error_lower or
            "cannot contain these characters" in error_lower or
            "hybriddeliveryexception"         in error_lower or
            "[,;{}()"                         in error_lower or
            "parquetinvalid"                  in error_lower
        ):
            entry  = get_error_by_code("ADF-006")
            result = {
                "matched_error_code": "ADF-006",
                "matched_error_name": "Parquet Invalid Column Name",
                "error_class":        "KNOWN",
                "confidence":         0.95,
                "detected_root_cause": (
                    entry.main_cause if entry
                    else "Column name contains Parquet-invalid characters"
                ),
                "resolution_action": (
                    entry.resolution_action if entry
                    else "sanitise_parquet_column_names"
                ),
                "llm_fix_plan": (
                    entry.troubleshooting_steps[:3] if entry
                    else [
                        "Identify invalid column names in ADF Copy Activity → Mapping",
                        "Rename columns to remove ; { } ( ) = characters",
                        "Re-publish ADF pipeline and re-run",
                    ]
                ),
                "auto_resolvable":    entry.auto_resolvable if entry else False,
                "severity":           entry.severity if entry else "HIGH",
                "explanation":        "Priority rule matched ParquetInvalidColumnName → ADF-006",
                "detection_method":   "keyword_fallback_priority_rule",
            }
            self._enrich(result)
            return result

        # ── Normal catalog keyword scan ───────────────────────────────────
        best_score = 0
        best_entry = None

        for entry in ADF_ERROR_CATALOG:
            score = sum(1 for kw in entry.keywords if kw.lower() in error_lower)
            if score > best_score:
                best_score = score
                best_entry = entry

        if best_entry and best_score > 0:
            confidence = min(best_score / max(len(best_entry.keywords), 1), 0.75)
            result = {
                "matched_error_code":  best_entry.error_code,
                "matched_error_name":  best_entry.error_name,
                "error_class":         "KNOWN",
                "confidence":          confidence,
                "detected_root_cause": best_entry.main_cause,
                "resolution_action":   best_entry.resolution_action,
                "llm_fix_plan":        best_entry.troubleshooting_steps[:3],
                "auto_resolvable":     best_entry.auto_resolvable,
                "severity":            best_entry.severity,
                "explanation":         f"Keyword fallback match (score={best_score})",
                "detection_method":    "keyword_fallback",
            }
            self._enrich(result)
            return result

        return {
            "matched_error_code":  "UNKNOWN",
            "matched_error_name":  "Unknown Error",
            "error_class":         "UNKNOWN",
            "confidence":          0.0,
            "detected_root_cause": "Could not determine root cause",
            "resolution_action":   "manual_investigation_required",
            "llm_fix_plan":        [
                "Check ADF Monitor → Pipeline runs → Activity runs",
                "Review error message in Log Analytics",
                "Escalate to L2 support",
            ],
            "auto_resolvable":     False,
            "severity":            "HIGH",
            "explanation":         "No catalog match found — manual investigation required",
            "detection_method":    "keyword_fallback",
        }

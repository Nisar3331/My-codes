"""
=======================================================
  HttpTrigger1 — ADF Self-Healing Handler
  FIXED: raw_error_code prepended to error_message
         so fallback detection sees ParquetInvalidColumnName
=======================================================
"""

import json
import logging
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import azure.functions as func

from src.llm_error_detector import LlmErrorDetector
from src.error_resolver import AdfErrorResolver
from src.adf_pipeline_manager import AdfPipelineManager
from src.policy import evaluate_policy, PolicyOutcome
from src.incident_store import is_already_handled, mark_as_handled
from config.settings import AZURE_CONFIG

CODE_VERSION = "ADF_SELF_HEALING_V3_FIXED_2026_05_07"


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("=" * 80)
    logging.info("=== HttpTrigger1 — Monitor Alert received ===")
    logging.info("CODE_VERSION = %s", CODE_VERSION)
    logging.info("=" * 80)

    try:
        body = req.get_json()
    except Exception as exc:
        logging.error("Failed to parse request body: %s", exc)
        return func.HttpResponse(
            json.dumps({"error": "Invalid JSON body"}),
            status_code=400,
            mimetype="application/json",
        )

    logging.info("Payload preview: %s", json.dumps(body, default=str)[:800])

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 1 — ERROR DETECTION
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEP 1 — Error Detection from current alert result")
    pipeline_info = _extract_from_payload(body)

    if not pipeline_info:
        logging.warning("No pipeline info — ignoring alert")
        return func.HttpResponse(
            json.dumps({"status": "ignored"}),
            status_code=200,
            mimetype="application/json",
        )

    pipeline_name  = pipeline_info["pipeline_name"]
    run_id         = pipeline_info.get("run_id", "unknown")
    activity_name  = pipeline_info.get("activity_name")
    raw_error_code = pipeline_info.get("error_code", "")
    error_message  = pipeline_info.get("error_message", "")

    # FIX — prepend raw_error_code so fallback detection sees it
    # e.g. "ParquetInvalidColumnName: The column name is invalid..."
    full_error = f"{raw_error_code}: {error_message}".strip(": ") if raw_error_code else error_message

    logging.error(
        "ADF FAILURE DETECTED | pipeline=%s | run_id=%s | activity=%s | "
        "raw_error_code=%s | source=%s | error=%s",
        pipeline_name, run_id, activity_name,
        raw_error_code, pipeline_info.get("source"), str(error_message)[:200],
    )

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 2 — CLASSIFY + LLM GENERATES FIX
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEP 2 — Classify + LLM fix generation | pipeline=%s", pipeline_name)
    try:
        detector  = LlmErrorDetector()
        detection = detector.detect(
            error_message=full_error,   # FIX — pass raw_error_code + message
            pipeline_name=pipeline_name,
            activity_name=activity_name,
        )
        logging.info(
            "[%s] Class=%s | Code=%s | Confidence=%.0f%% | Auto=%s | LLM fix=%s",
            pipeline_name,
            detection.get("error_class"),
            detection.get("matched_error_code"),
            detection.get("confidence", 0) * 100,
            detection.get("auto_resolvable"),
            str(detection.get("llm_fix_plan", []))[:150],
        )
    except Exception as exc:
        logging.error("[%s] LLM detection failed: %s", pipeline_name, exc)
        detection = {
            "matched_error_code": raw_error_code or "UNKNOWN",
            "error_class":        "UNKNOWN",
            "confidence":         0.0,
            "auto_resolvable":    False,
            "resolution_action":  "manual_investigation_required",
            "llm_fix_plan":       ["Check ADF Monitor", "Review Log Analytics", "Escalate to L2"],
        }

    detected_code = detection.get("matched_error_code", "UNKNOWN")

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 5 — EXECUTE FIX
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEP 5 — Execute fix | pipeline=%s | action=%s",
                 pipeline_name, detection.get("resolution_action"))
    try:
        resolver   = AdfErrorResolver()
        resolution = resolver.resolve(detection)
        logging.info(
            "[%s] Resolver: success=%s | validator_passed=%s | %s",
            pipeline_name,
            resolution.get("success"),
            resolution.get("validator_passed"),
            resolution.get("message", "")[:150],
        )
    except Exception as exc:
        logging.error("[%s] Resolver failed: %s", pipeline_name, exc)
        resolution = {"success": False, "validator_passed": False}

    # ═══════════════════════════════════════════════════════════════════════
    # STEPS 3+4 — SAFETY CHECK + NOTIFY
    # ═══════════════════════════════════════════════════════════════════════
    logging.info("STEPS 3+4 — Safety check + notify | pipeline=%s", pipeline_name)
    already_handled = is_already_handled(pipeline_name, detected_code)

    decision = evaluate_policy(
        detection=detection,
        resolution=resolution,
        pipeline_name=pipeline_name,
        already_handled=already_handled,
    )

    logging.info(
        "[%s] Policy → outcome=%s | blast=%s | notify=%s | reason=%s",
        pipeline_name, decision.outcome, decision.blast_radius,
        decision.notify_team, decision.rationale,
    )

    # ═══════════════════════════════════════════════════════════════════════
    # STEP 6 — RERUN PIPELINE
    # ═══════════════════════════════════════════════════════════════════════
    restart_result = {"restarted": False, "reason": decision.rationale}
    status_result  = {}

    if decision.outcome == PolicyOutcome.EXECUTE:
        logging.info("STEP 6 — Rerun pipeline | pipeline=%s", pipeline_name)
        try:
            mgr        = AdfPipelineManager()
            new_run_id = mgr.restart_pipeline(
                pipeline_name=pipeline_name,
                delay_seconds=30,
            )
            restart_result = {"restarted": True, "new_run_id": new_run_id}
            logging.info("[%s] RESTARTED SUCCESSFULLY | new_run_id=%s",
                         pipeline_name, new_run_id)
            mark_as_handled(pipeline_name, detected_code, run_id)

            # STEP 7 — CHECK STATUS
            logging.info("STEP 7 — Check status | new_run_id=%s", new_run_id)
            try:
                import time
                time.sleep(60)
                status_result = mgr.check_status(new_run_id)
                logging.info("[%s] Status: %s | duration=%ss",
                             pipeline_name,
                             status_result.get("status"),
                             status_result.get("duration_seconds"))
            except Exception as exc:
                logging.warning("[%s] Status check failed: %s", pipeline_name, exc)
                status_result = {"status": "CheckFailed", "error": str(exc)}

        except Exception as exc:
            restart_result = {"restarted": False, "error": str(exc)}
            logging.error("[%s] Restart failed: %s", pipeline_name, exc)

    elif decision.outcome == PolicyOutcome.BLOCKED:
        logging.error(
            "[%s] BLOCKED — manual fix required | code=%s | reason=%s | fix=%s",
            pipeline_name, detected_code, decision.rationale, decision.llm_fix,
        )
        mark_as_handled(pipeline_name, detected_code, run_id)

    elif decision.outcome == PolicyOutcome.NOTIFY:
        logging.warning(
            "[%s] NOTIFY — team alerted | code=%s | reason=%s",
            pipeline_name, detected_code, decision.rationale,
        )
        mark_as_handled(pipeline_name, detected_code, run_id)

    elif decision.outcome == PolicyOutcome.SKIPPED:
        logging.info("[%s] SKIPPED — duplicate", pipeline_name)

    # ── Final result ──────────────────────────────────────────────────────
    result = {
        "code_version": CODE_VERSION,
        "step1_detection": {
            "pipeline_name": pipeline_name,
            "run_id":        run_id,
            "activity_name": activity_name,
            "raw_error_code": raw_error_code,
            "error_message": str(error_message)[:200],
            "source":        pipeline_info.get("source"),
        },
        "step2_classification": {
            "error_code":  detected_code,
            "error_class": detection.get("error_class"),
            "confidence":  detection.get("confidence", 0),
            "llm_fix":     decision.llm_fix,
        },
        "step3_blast_radius": str(decision.blast_radius),
        "step4_notified":     decision.notify_team,
        "step5_resolution": {
            "success":          resolution.get("success"),
            "validator_passed": resolution.get("validator_passed"),
            "message":          resolution.get("message", ""),
        },
        "step6_restart":  restart_result,
        "step7_status":   status_result,
        "policy_outcome": str(decision.outcome),
        "rationale":      decision.rationale,
    }

    logging.info("[%s] All steps complete: %s",
                 pipeline_name, json.dumps(result, default=str))

    return func.HttpResponse(
        json.dumps(result, default=str),
        status_code=200,
        mimetype="application/json",
    )


def _extract_from_payload(data: dict) -> dict | None:
    payload   = data.get("data", data)
    alert_ctx = payload.get("alertContext", {})

    # Log alertContext keys for debugging
    logging.info("AlertContext keys: %s", list(alert_ctx.keys()))

    # Priority 1 — searchResults
    search = alert_ctx.get("searchResults", {})
    tables = search.get("tables", [])
    logging.info("searchResults tables: %d", len(tables))

    if tables and tables[0].get("rows"):
        columns = [c["name"] for c in tables[0]["columns"]]
        values  = tables[0]["rows"][0]
        row     = dict(zip(columns, values))
        logging.info("Row from searchResults: %s", json.dumps(row, default=str))
        pipeline_name = row.get("pipelineName") or row.get("PipelineName") or ""
        if pipeline_name:
            return {
                "pipeline_name": pipeline_name,
                "run_id":        row.get("runId") or row.get("RunId"),
                "activity_name": row.get("activityName") or row.get("ActivityName"),
                "error_code":    row.get("errorCode") or row.get("ErrorCode"),
                "error_message": row.get("errorMessage") or row.get("ErrorMessage") or "",
                "source":        "searchResults",
            }

    # Priority 2 — query via linkToSearchResultsAPI in the alert condition
    condition = alert_ctx.get("condition", {})
    all_of    = condition.get("allOf", [])
    if all_of:
        logging.info("Alert condition preview: %s", json.dumps(condition, default=str)[:500])
        api_url = all_of[0].get("linkToSearchResultsAPI", "")
        if api_url:
            result = _fetch_alert_results(api_url)
            if result:
                return result

    # Priority 3 — properties fallback
    logging.warning("searchResults empty — using properties fallback")
    essentials = payload.get("essentials", {})
    properties = alert_ctx.get("properties", {})

    if essentials.get("monitorCondition") == "Resolved":
        return None

    return {
        "pipeline_name": (
            properties.get("pipelineName") or
            AZURE_CONFIG.adf_pipeline_name or
            "unknown-pipeline"
        ),
        "run_id":        properties.get("runId"),
        "activity_name": properties.get("activityName"),
        "error_code":    properties.get("errorCode"),
        "error_message": (
            properties.get("errorMessage") or
            f"ADF pipeline failure"
        ),
        "source": "properties_fallback",
    }


def _fetch_alert_results(api_url: str) -> dict | None:
    """
    Fetch actual query results from the linkToSearchResultsAPI URL.
    This URL is embedded in the alert payload and returns the real
    Log Analytics rows that triggered the alert.
    """
    try:
        import urllib.request
        from azure.identity import ClientSecretCredential

        # Get access token for Log Analytics API
        cred  = ClientSecretCredential(
            tenant_id=AZURE_CONFIG.tenant_id,
            client_id=AZURE_CONFIG.client_id,
            client_secret=AZURE_CONFIG.client_secret,
        )
        token = cred.get_token("https://api.loganalytics.io/.default").token

        req = urllib.request.Request(
            api_url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type":  "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            status = resp.status
            body   = resp.read().decode("utf-8")
            logging.info("Alert results API status: %d", status)
            logging.info("Alert results API body: %s", body[:500])

        data   = json.loads(body)
        tables = data.get("tables", [])

        if not tables or not tables[0].get("rows"):
            logging.warning("Alert results API returned no rows")
            return None

        cols = [c["name"] for c in tables[0]["columns"]]
        row  = dict(zip(cols, tables[0]["rows"][0]))
        logging.info("Row from alert results API: %s", json.dumps(row, default=str))

        pipeline_name = row.get("pipelineName") or row.get("PipelineName") or ""
        if not pipeline_name:
            return None

        return {
            "pipeline_name": pipeline_name,
            "run_id":        row.get("runId") or row.get("RunId"),
            "activity_name": row.get("activityName") or row.get("ActivityName"),
            "error_code":    row.get("errorCode") or row.get("ErrorCode"),
            "error_message": row.get("errorMessage") or row.get("ErrorMessage") or "",
            "source":        "alert_results_api",
        }

    except Exception as exc:
        logging.error("_fetch_alert_results failed: %s", exc)
        return None
